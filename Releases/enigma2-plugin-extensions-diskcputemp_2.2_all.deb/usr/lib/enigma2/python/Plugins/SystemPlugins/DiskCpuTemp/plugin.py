# -*- coding: utf-8 -*-
from __future__ import print_function, division
#
# plugin by iet5
#
import os
import sys
import subprocess
import re
import time
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigSelection
from enigma import eTimer, getDesktop, gRGB
from Plugins.Plugin import PluginDescriptor

# Add the script folder path to sys.path
plugin_dir = os.path.dirname(os.path.realpath(__file__))
if plugin_dir not in sys.path:
    sys.path.append(plugin_dir)

# Import from our other modules
try:
    from temp_utilities import *
    from screen import *
except Exception as e:
    print("[DiskCpuTemp] Error importing modules: %s" % str(e))

# Global variables
log_file = "/tmp/diskcputemp.log"

# Configuration setup
if not hasattr(config.plugins, "DiskCpuTemp"):
    config.plugins.DiskCpuTemp = ConfigSubsection()

config.plugins.DiskCpuTemp.warning_duration = ConfigSelection(
    choices=[
        ("5000", "5 seconds"),
        ("10000", "10 seconds"),
        ("15000", "15 seconds"),
        ("20000", "20 seconds")
    ],
    default="5000"
)

# Save last chosen skin so it persists after restart
config.plugins.DiskCpuTemp.last_skin = ConfigSelection(
    choices=[
        ("Fhd1", "Fhd1"),
        ("Fhd2", "Fhd2")
    ],
    default="Fhd2"
)

# --------- Version from file ---------
plugin_path = os.path.dirname(os.path.realpath(__file__))
version_file = os.path.join(plugin_path, "version.txt")
plugin_version = "Unknown"
try:
    with open(version_file, "r") as f:
        plugin_version = f.read().strip()
        if not plugin_version:
            plugin_version = "Unknown"
except Exception as e:
    print("[Plugin] Error reading version.txt: %s" % str(e))
    plugin_version = "Unknown"

# --- Main Screen Class ---
class DiskCpuTempScreen(Screen, UIScreenMethods):
    instance = None

    def __init__(self, session):
        self.session = session
        DiskCpuTempScreen.instance = self

        # detect screen resolution
        desktop_size = getDesktop(0).size()
        width = desktop_size.width()
        height = desktop_size.height()

        # Choose skin based on saved preference (persisted in config)
        try:
            skin_choice = config.plugins.DiskCpuTemp.last_skin.value
        except Exception:
            skin_choice = "Fhd2"

        if skin_choice == "Fhd1":
            self.skin = self._skin_fhd1()
        else:
            self.skin = self._skin_fhd2()

        Screen.__init__(self, session)

        # Get warning duration from configuration
        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
        except Exception:
            warning_duration = 5000

        # Initialize header
        self["plugin_name"] = Label("Disk & CPU Temperature by Iet5")
        self["version"] = Label("Ver " + plugin_version)
        self["warning_bar"] = Label("")  # Initialize warning bar

        # Initialize other widgets
        self["cpu_label"] = Label("CPU Temp: Loading...")
        self["hdd1_label"] = Label("")
        self["hdd2_label"] = Label("")
        self["hdd3_label"] = Label("")
        self["hdd4_label"] = Label("")
        self["update_label"] = Label("Update every 5 Seconds")
        self["settings_label"] = Label("Warning Duration: %d seconds" % (warning_duration / 1000))
        self["settings_hint"] = Label("Press UP/DOWN to change warning duration")
        self["exit_button"] = Label("Exit")
        self["save_button"] = Label("Save")
        self["change_skin_button"] = Label("Change Skin")
        self["stop_warning_button"] = Label("Stop Warning")

        # Action map
        self["actions"] = ActionMap(
            ["SetupActions", "OkCancelActions", "ChannelSelectActions",
             "InfobarChannelSelection", "DirectionActions", "NumberActions", "ColorActions"], {
                "ok": self.close,
                "cancel": self.close,
                "red": self.exit_plugin,
                "green": self.save_only,
                "yellow": self.change_skin,
                "blue": self.toggle_warnings,
                "up": self.increase_duration,
                "down": self.decrease_duration
            }, -1
        )

        # Timer setup
        self.updateTimer = eTimer()
        try:
            # Compatibility for both eTimer interfaces
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateTemps)
        except:
            try:
                self.updateTimer.callback.append(self.updateTemps)
            except:
                self.updateTimer = None

        self.onShown.append(self.startTimer)
        self.onHide.append(self.stopTimer)

    def __del__(self):
        # Clean up resources
        try:
            if hasattr(self, 'updateTimer') and self.updateTimer is not None:
                self.updateTimer.stop()
                self.updateTimer = None
        except:
            pass
        if DiskCpuTempScreen.instance == self:
            DiskCpuTempScreen.instance = None

    # --- Temperature update delegated to temp_utilities --- 
    def get_cpu_temp(self):
        """Proxy to temp_utilities for backward compatibility if needed"""
        try:
            from temp_utilities import get_cpu_temp as read_cpu
            return read_cpu()
        except:
            return "N/A"

# --- Main Functions ---
def main(session, **kwargs):
    try:
        if "clear_log" in globals():
            clear_log()
        session.open(DiskCpuTempScreen)
    except Exception as e:
        print("[DiskCpuTemp] Error opening screen: %s" % str(e))
        try:
            session.open(MessageBox, "Error opening DiskCpuTempScreen: %s" % str(e), MessageBox.TYPE_ERROR)
        except:
            pass

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Disk & CPU Temperature by Iet5",
            description="Show CPU and HDD/SSD/NVMe temperatures",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            name="Disk & CPU Temperature",
            description="Show CPU and HDD temperatures",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        )
    ]