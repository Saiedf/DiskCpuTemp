# -*- coding: utf-8 -*-
from __future__ import print_function, division
import os
import subprocess
import re
import time
import sys

# -----------------------------------------------------------------------------
# Python 2 / 3 compatibility helpers
# -----------------------------------------------------------------------------
PY2 = (sys.version_info[0] == 2)

try:
    text_type = unicode  # noqa: F821  # Python 2
except NameError:
    text_type = str

try:
    string_types = (basestring,)  # noqa: F821  # Python 2
except NameError:
    string_types = (str,)


def ensure_text(value, encoding="utf-8"):
    """Return unicode/text safely in Python 2 and 3."""
    if value is None:
        return ""
    if isinstance(value, text_type):
        return value
    try:
        return value.decode(encoding, "ignore")
    except Exception:
        try:
            return text_type(value)
        except Exception:
            return ""

# Try to import real gRGB from enigma (used by Enigma2 UI). If not available, enigma_gRGB will be None.
from Components.config import config
try:
    from enigma import eTimer, gRGB as enigma_gRGB
except:
    enigma_gRGB = None

def gRGB(r, g, b): return (r, g, b)

# Python 2 / 3 compatibility helpers
PY2 = (sys.version_info[0] == 2)

# Global variables
log_file = "/tmp/diskcputemp.log"

# HDD Warning thresholds
HDD_FIRST_WARNING_TEMP = 45
HDD_SECOND_WARNING_TEMP = 50
HDD_FINAL_WARNING_TEMP = 55

# CPU Warning thresholds
CPU_FIRST_WARNING_TEMP = 75
CPU_SECOND_WARNING_TEMP = 80
CPU_FINAL_WARNING_TEMP = 85

# Warning system variables
warning_active = False
warning_level = {"CPU": 0, "/dev/sda": 0, "/dev/sdb": 0, "/dev/sdc": 0}
warning_timer = None
warnings_enabled = True  # Global variable to control warning display

# ==== Logging ====
def log_message(message):
    """Write message to log file with timestamp"""
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%H:%M:%S")
            f.write("[%s] %s\n" % (timestamp, ensure_text(message)))
    except:
        pass

def clear_log():
    """Clear the log file"""
    try:
        with open(log_file, "w") as f:
            f.write("")
        log_message("Log file cleared")
    except:
        pass

# ==== Environment detection ====
def get_distro():
    """Detect Enigma2 image/distro"""
    try:
        if os.path.exists("/etc/image-version"):
            with open("/etc/image-version", "r") as f:
                content = f.read().lower()
                if "openatv" in content: return "openatv"
                if "vti" in content: return "vti"
                if "openpli" in content: return "openpli"
        if os.path.exists("/etc/os-release"):
            with open("/etc/os-release", "r") as f:
                content = f.read().lower()
                if "dreamos" in content or "opendreambox" in content: return "dreamos"
    except:
        pass
    return "opensource"

DISTRO = get_distro()

# ==== Temperature parsing ====
def extract_temperature_value(temp_string):
    """Extract numeric temperature value from string, handling various formats and normalizing to Celsius"""
    if temp_string is None:
        return None
    
    text = ensure_text(temp_string).strip()
    if not text or "N/A" in text.upper():
        return None

    # Remove degree sign (\xb0) and other common units
    text = text.replace(u"\u00b0", " ").replace("C", " ").replace("c", " ")
    text = text.replace("temp", " ").replace(":", " ")

    # Extraction regex for floats/ints
    match = re.search(r"(-?\d+(?:\.\d+)?)", text)
    if not match:
        return None

    try:
        temp = float(match.group(1))
    except:
        return None

    # Normalize drivers that expose millidegrees (e.g. 45000 -> 45.0)
    if abs(temp) > 1000:
        temp = temp / 1000.0
    
    # Filter obviously invalid sensor values
    if temp < -20 or temp > 200:
        return None

    return temp

# ==== Color mapping ====
def temp_to_color(temp, device_type="CPU"):
    """
    Return a color corresponding to temperature.
    This function returns a real enigma.gRGB object when available.
    """
    try:
        temp_value = extract_temperature_value(temp)
        if temp_value is None:
            return enigma_gRGB(255, 255, 255) if enigma_gRGB else gRGB(255, 255, 255)
    except:
        return enigma_gRGB(255, 255, 255) if enigma_gRGB else gRGB(255, 255, 255)

    if device_type == "CPU":
        min_temp, max_temp = 30.0, 85.0
    else:
        min_temp, max_temp = 25.0, 55.0

    temp_value = max(min_temp, min(temp_value, max_temp))
    norm = (temp_value - min_temp) / (max_temp - min_temp)

    color_ranges = [
        (0.0, 0.2, (0, 0, 255)),      # Blue
        (0.2, 0.4, (0, 255, 255)),    # Sky blue
        (0.4, 0.6, (0, 255, 0)),      # Green
        (0.6, 0.8, (255, 255, 0)),    # Yellow
        (0.8, 1.0, (255, 0, 0))       # Red
    ]

    r, g, b = 255, 255, 255
    for start, end, (rr, gg, bb) in color_ranges:
        if start <= norm <= end:
            ratio = (norm - start) / (end - start) if end != start else 0
            if start == 0.0: r, g, b = 0, int(255 * ratio), 255
            elif start == 0.2: r, g, b = 0, 255, int(255 * (1 - ratio))
            elif start == 0.4: r, g, b = int(255 * ratio), 255, 0
            elif start == 0.6: r, g, b = 255, int(255 * (1 - ratio) + 165 * ratio), 0
            else: r, g, b = 255, int(165 * (1 - ratio)), 0
            break

    # Lighten colors slightly for better readability on dark backgrounds
    lighten = 180
    r, g, b = min(255, r + lighten), min(255, g + lighten), min(255, b + lighten)

    if enigma_gRGB:
        try: return enigma_gRGB(r, g, b)
        except: return gRGB(r, g, b)
    return gRGB(r, g, b)

# ==== Warning system ====
def check_temperature_warnings(device_type, device_name, temperature):
    global warning_active, warning_level, warnings_enabled
    if not warnings_enabled: return

    try:
        temp_value = extract_temperature_value(temperature)
        if temp_value is None: return

        if device_type in ("HDD", "SSD", "NVMe") and temp_value > 100:
            log_message("Ignoring unrealistic storage temperature: %s (%s)" % (temperature, device_name))
            return

        if device_type == "CPU":
            first, second, final = CPU_FIRST_WARNING_TEMP, CPU_SECOND_WARNING_TEMP, CPU_FINAL_WARNING_TEMP
        else:
            first, second, final = HDD_FIRST_WARNING_TEMP, HDD_SECOND_WARNING_TEMP, HDD_FINAL_WARNING_TEMP

        if device_name not in warning_level: warning_level[device_name] = 0

        if temp_value >= final and warning_level[device_name] < 3:
            show_warning(device_name, 3, temp_value)
            warning_level[device_name] = 3
        elif temp_value >= second and warning_level[device_name] < 2:
            show_warning(device_name, 2, temp_value)
            warning_level[device_name] = 2
        elif temp_value >= first and warning_level[device_name] < 1:
            show_warning(device_name, 1, temp_value)
            warning_level[device_name] = 1
        elif temp_value < first and warning_level[device_name] > 0:
            warning_level[device_name] = 0
            clear_warning_bar(device_name)
            if all(level == 0 for level in warning_level.values()):
                try:
                    from plugin import DiskCpuTempScreen
                    if DiskCpuTempScreen.instance: DiskCpuTempScreen.instance.clear_warning_bar()
                except: pass
    except Exception as e:
        log_message("Exception in check_temperature_warnings: %s" % str(e))

def show_warning(device_name, level, temperature_value):
    global warning_active, warning_timer, warnings_enabled
    if not warnings_enabled: return

    try:
        warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
    except:
        warning_duration = 5000

    timeout_seconds = warning_duration / 1000
    display_name = device_name
    temp_display = "%.1f C" % temperature_value if device_name == "CPU" else "%d C" % temperature_value

    if level == 1:
        message = "First warning: %s temperature %s" % (display_name, temp_display)
        warning_bar_text = "FIRST WARNING: %s TEMP %s" % (display_name, temp_display)
    elif level == 2:
        message = "Second warning: %s temperature %s" % (display_name, temp_display)
        warning_bar_text = "SECOND WARNING: %s TEMP %s" % (display_name, temp_display)
    else:
        message = "Final warning: %s temperature %s" % (display_name, temp_display)
        warning_bar_text = "FINAL WARNING: %s TEMP %s" % (display_name, temp_display)

    log_message("WARNING: " + message)

    try:
        from plugin import DiskCpuTempScreen
        if DiskCpuTempScreen.instance and DiskCpuTempScreen.instance.session:
            from Screens.MessageBox import MessageBox
            DiskCpuTempScreen.instance.session.open(MessageBox, str(message), type=MessageBox.TYPE_ERROR, timeout=timeout_seconds)
        if DiskCpuTempScreen.instance:
            DiskCpuTempScreen.instance.show_warning_bar(warning_bar_text)
    except Exception as e:
        log_message("Warning UI failed: %s" % str(e))

    try:
        if warning_timer: warning_timer.stop()
        from enigma import eTimer
        warning_timer = eTimer()
        try: warning_timer.timeout.get().append(clear_warning)
        except: warning_timer.callback.append(clear_warning)
        warning_timer.start(warning_duration, 1)
    except: pass
    warning_active = True

def clear_warning():
    global warning_active
    warning_active = False

def clear_warning_bar(device_name):
    try:
        from plugin import DiskCpuTempScreen
        if DiskCpuTempScreen.instance:
            if all(level == 0 for level in warning_level.values()):
                DiskCpuTempScreen.instance.clear_warning_bar()
    except: pass

# ==== Temperature reading ====
CPU_TEMP_PATHS = [
    "/sys/class/thermal/thermal_zone0/temp",
    "/sys/class/thermal/thermal_zone1/temp",
    "/sys/class/hwmon/hwmon0/temp1_input",
    "/sys/class/hwmon/hwmon1/temp1_input",
    "/proc/stb/sensors/temp0/value",
    "/proc/stb/fp/temp_sensor",
    "/proc/stb/fp/temp_sensor_avs",
    "/proc/stb/power/avs",
    # Additional paths for specific boxes
    "/sys/devices/virtual/thermal/thermal_zone0/temp",
    "/proc/stb/sensors/temp/value",
]

def get_cpu_temp():
    """Unified CPU temperature reader with fallback logic"""
    for path in CPU_TEMP_PATHS:
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    content = f.read().strip()
                val = extract_temperature_value(content)
                if val is not None:
                    return "%.1f C" % val
            except: continue
    
    # Fallback to sensors command
    try:
        p = subprocess.Popen(["sensors"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        out = ensure_text(out)
        # Search for common CPU temp lines
        m = re.search(r'(?i)(cpu|package id 0|temp1).*?:\s*\+?(\d+(\.\d+)?)', out)
        if m:
            val = float(m.group(2))
            return "%.1f C" % val
    except: pass
    
    return "N/A"

def get_nvme_sys_temp(dev_name):
    """Direct NVMe sysfs temperature reading"""
    # Try to find hwmon for the nvme device
    try:
        base_path = "/sys/class/nvme/%s/device/hwmon" % dev_name
        if os.path.exists(base_path):
            for hwmon in os.listdir(base_path):
                temp_path = os.path.join(base_path, hwmon, "temp1_input")
                if os.path.exists(temp_path):
                    with open(temp_path, "r") as f:
                        val = extract_temperature_value(f.read().strip())
                    if val is not None: return "%d C" % val
    except: pass
    return None

def get_smartctl_temp(device_path):
    """Get temperature using smartctl"""
    smartctl_path = "/usr/sbin/smartctl"
    if not os.path.exists(smartctl_path): return None
    
    dev_type = "nvme" if "nvme" in device_path else "sat"
    commands = [
        [smartctl_path, "-A", device_path],
        [smartctl_path, "-A", "-d", dev_type, device_path],
        [smartctl_path, "-a", device_path]
    ]

    for cmd in commands:
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p.communicate()
            if p.returncode != 0: continue
            output = ensure_text(out)

            # SMART output parsing
            for line in output.splitlines():
                if re.search(r'\b(Temperature_Celsius|Airflow_Temperature_Cel|Temperature|Current Drive Temperature|Composite Temperature)\b', line, re.IGNORECASE):
                    # Look for number near the end (RAW_VALUE)
                    match = re.search(r'(\d+)\s*(?:\(.*\)|$)', line)
                    if match:
                        val = int(match.group(1))
                        if 10 <= val <= 100: return "%d C" % val
        except: continue
    return None

def get_hddtemp_fallback(device_path):
    """Fallback using hddtemp-lite or hddtemp command"""
    try:
        p = subprocess.Popen(["hddtemp", "-n", device_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        val = extract_temperature_value(ensure_text(out))
        if val is not None: return "%d C" % val
    except: pass
    return None

# ==== Device detection ====
def detect_all_storage_devices():
    """Detect all storage devices (SATA, IDE, NVMe, eMMC)"""
    devices = []
    try:
        # SATA / SD
        for d in os.listdir("/dev/"):
            if re.match(r'^sd[a-z]$', d): devices.append("/dev/" + d)
            elif re.match(r'^hd[a-z]$', d): devices.append("/dev/" + d)
            elif re.match(r'^nvme\d+n\d+$', d): devices.append("/dev/" + d)
            elif re.match(r'^mmcblk\d+$', d): devices.append("/dev/" + d)
    except: pass
    return sorted(list(set(devices)))

def get_device_info(device_path):
    """Determine device type and better display name"""
    name = device_path.split("/")[-1]
    if "nvme" in name: return "NVMe", name
    if "mmcblk" in name: return "eMMC", name
    
    # Check for SSD vs HDD
    dtype = "HDD"
    # Method 1: Rotational queue
    try:
        rot_path = "/sys/block/%s/queue/rotational" % name
        if os.path.exists(rot_path):
            with open(rot_path, "r") as f:
                if f.read().strip() == "0": dtype = "SSD"
    except: pass
    
    # Method 2: smartctl info (if still HDD)
    if dtype == "HDD":
        try:
            p = subprocess.Popen(["smartctl", "-i", device_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p.communicate()
            output = ensure_text(out).upper()
            if "SSD" in output or "SOLID STATE" in output:
                dtype = "SSD"
        except: pass
        
    return dtype, name

def get_hdd_temps():
    """Main function to gather all storage temperatures - filters out N/A by default"""
    devices = detect_all_storage_devices()
    results = {}
    
    counts = {"HDD": 1, "SSD": 1, "NVMe": 1, "eMMC": 1}
    
    for dev_path in devices:
        dtype, dev_name = get_device_info(dev_path)
        temp = None
        
        # Priority 1: Sysfs (NVMe/eMMC specific)
        if dtype == "NVMe":
            temp = get_nvme_sys_temp(dev_name)
        
        # Priority 2: smartctl
        if temp is None:
            temp = get_smartctl_temp(dev_path)
        
        # Priority 3: hddtemp fallback
        if temp is None:
            temp = get_hddtemp_fallback(dev_path)
            
        if temp is None: temp = "N/A"
        
        # Only add to results if temperature is valid (as requested by user)
        if temp != "N/A":
            label = "%s%d-%s" % (dtype, counts[dtype], dev_name)
            results[label] = temp
            counts[dtype] += 1
        
    return results

def get_drive_temps():
    temps_dict = get_hdd_temps()
    return [(k, v) for k, v in temps_dict.items()]

def show_drive_summary_with_temp():
    """Standalone summary for command line testing"""
    cpu = get_cpu_temp()
    print("CPU: %s" % cpu)
    storage = get_hdd_temps()
    for k, v in storage.items():
        print("%s: %s" % (k, v))

if __name__ == "__main__":
    show_drive_summary_with_temp()