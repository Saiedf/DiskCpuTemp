# -*- coding: utf-8 -*-
from __future__ import print_function, division
import os
import subprocess
import re
import time
import sys
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config
from enigma import eTimer, getDesktop, gRGB

# Import from our other modules
try:
    from temp_utilities import *
except:
    pass

# -----------------------------------------------------------------------------
# Python 2 / 3 compatibility helpers
# -----------------------------------------------------------------------------
PY2 = (sys.version_info[0] == 2)

try:
    text_type = unicode  # noqa: F821  # Python 2
except NameError:
    text_type = str

def ensure_text(value, encoding="utf-8"):
    if value is None: return ""
    if isinstance(value, text_type): return value
    try: return value.decode(encoding, "ignore")
    except:
        try: return text_type(value)
        except: return ""

# --- UI Screen Methods ---
class UIScreenMethods:
    # --- Skins ---
    def _skin_fhd1(self):
        # Full screen FHD (900x630) skin
        return """
        <screen name="DiskCpuTempScreen" position="center,center" size="900,630" title="" flags="wfNoBorder">
            <widget name="plugin_name" position="30,13" size="540,30" font="Regular;28" halign="left" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="version" position="750,13" size="120,30" font="Regular;28" halign="right" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="warning_bar" position="30,150" size="840,40" font="Regular;28" halign="center" foregroundColor="#FF0000" transparent="1"/>

            <!-- Buttons -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/red.png" position="40,75" size="190,50" scale="stretch" alphatest="on" zPosition="1" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/green.png" position="240,75" size="190,50" scale="stretch" alphatest="on" zPosition="1" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/yellow.png" position="440,75" size="190,50" scale="stretch" alphatest="on" zPosition="1" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/blue.png" position="640,75" size="190,50" scale="stretch" alphatest="on" zPosition="1" />
            <widget name="exit_button" position="40,75" size="190,50" font="Regular;26" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#FF0000" transparent="1" zPosition="3"/>
            <widget name="save_button" position="240,75" size="190,50" font="Regular;26" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00FF00" transparent="1" zPosition="3"/>
            <widget name="change_skin_button" position="440,75" size="190,50" font="Regular;26" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#FFFF00" transparent="1" zPosition="3"/>
            <widget name="stop_warning_button" position="640,75" size="190,50" font="Regular;26" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000FF" transparent="1" zPosition="3"/>

            <!-- Content section -->
            <widget name="cpu_label" position="30,200" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd1_label" position="30,260" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd2_label" position="30,310" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd3_label" position="30,360" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd4_label" position="30,410" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="settings_label" position="30,430" size="840,32" font="Regular;26" halign="center" foregroundColor="#00FF00" transparent="1"/>
            <widget name="update_label" position="30,470" size="840,32" font="Regular;26" halign="center" foregroundColor="#00BFFF" transparent="1"/>
            <widget name="settings_hint" position="30,510" size="840,32" font="Regular;26" halign="center" foregroundColor="#FFFF00" transparent="1"/>
        </screen>
        """

    def _skin_fhd2(self):
        # Full screen FHD (1920x1080) skin
        return """
        <screen name="DiskCpuTempScreen" position="0,0" size="1920,1080" title="" flags="wfNoBorder">
            <widget name="plugin_name" position="40,20" size="1740,60" font="Regular;36" halign="left" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="version" position="1760,20" size="120,60" font="Regular;32" halign="right" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="warning_bar" position="40,260" size="1840,70" font="Regular;34" halign="center" foregroundColor="#FF0000" transparent="1"/>

            <!-- Buttons -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/red.png" position="200,150" size="380,80" scale="stretch" alphatest="on" zPosition="1" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/green.png" position="600,150" size="380,80" scale="stretch" alphatest="on" zPosition="1" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/yellow.png" position="1000,150" size="380,80" scale="stretch" alphatest="on" zPosition="1" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DiskCpuTemp/buttons/blue.png" position="1400,150" size="380,80" scale="stretch" alphatest="on" zPosition="1" />
            <widget name="exit_button" position="200,150" size="380,80" font="Regular;30" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#FF0000" transparent="1" zPosition="3"/>
            <widget name="save_button" position="600,150" size="380,80" font="Regular;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00FF00" transparent="1" zPosition="3"/>
            <widget name="change_skin_button" position="1000,150" size="380,80" font="Regular;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#FFFF00" transparent="1" zPosition="3"/>
            <widget name="stop_warning_button" position="1400,150" size="380,80" font="Regular;30" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000FF" transparent="1" zPosition="3"/>

            <!-- Content section -->
            <widget name="cpu_label" position="100,310" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd1_label" position="100,380" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd2_label" position="100,450" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd3_label" position="100,520" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd4_label" position="100,590" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="settings_label" position="60,740" size="1840,50" font="Regular;30" halign="center" foregroundColor="#00FF00" transparent="1"/>
            <widget name="update_label" position="60,800" size="1840,50" font="Regular;30" halign="center" foregroundColor="#00BFFF" transparent="1"/>
            <widget name="settings_hint" position="60,860" size="1840,50" font="Regular;30" halign="center" foregroundColor="#FFFF00" transparent="1"/>
        </screen>
        """

    # --- Actions ---
    def save_only(self):
        try:
            config.plugins.DiskCpuTemp.warning_duration.save()
            config.plugins.save()
            self.show_temp_confirmation("Settings saved")
        except Exception as e:
            try: log_message("Failed to save config: %s" % str(e))
            except: pass

    def exit_plugin(self):
        try: self.close()
        except: pass

    def change_skin(self):
        try:
            current = config.plugins.DiskCpuTemp.last_skin.value
        except:
            current = "Fhd2"
        new_skin = "Fhd1" if current == "Fhd2" else "Fhd2"
        prompt = "Change skin to %s?\nEnigma will restart to apply the new skin." % new_skin

        try:
            self.session.openWithCallback(
                lambda answer, ns=new_skin: self._apply_skin_choice(answer, ns),
                MessageBox, prompt, type=MessageBox.TYPE_YESNO
            )
        except:
            self._apply_skin_choice(True, new_skin)

    def _apply_skin_choice(self, confirmed, new_skin):
        if not confirmed:
            self.show_temp_confirmation("Skin change cancelled")
            return
        try:
            config.plugins.DiskCpuTemp.last_skin.value = new_skin
            config.plugins.DiskCpuTemp.last_skin.save()
            config.plugins.save()
        except: pass

        # Restart Enigma2
        try:
            from Screens.Standby import TryQuitMainloop
            TryQuitMainloop(2)
        except:
            try: subprocess.call(["killall", "-9", "enigma2"])
            except: pass

    def toggle_warnings(self):
        global warnings_enabled, warning_level
        try:
            from temp_utilities import warnings_enabled as we, warning_level as wl
            import temp_utilities
            temp_utilities.warnings_enabled = not temp_utilities.warnings_enabled
            if temp_utilities.warnings_enabled:
                for d in temp_utilities.warning_level: temp_utilities.warning_level[d] = 0
                self["stop_warning_button"].setText("Stop Warning")
                self.show_temp_confirmation("Warnings enabled")
            else:
                self["stop_warning_button"].setText("Warnings stopped")
                self.clear_warning_bar()
                self.show_temp_confirmation("Warnings disabled")
        except: pass

    def startTimer(self):
        if hasattr(self, 'updateTimer') and self.updateTimer is not None:
            try:
                self.updateTimer.start(5000)
            except: pass
        self.updateTemps()

    def stopTimer(self):
        if hasattr(self, 'updateTimer') and self.updateTimer is not None:
            try: self.updateTimer.stop()
            except: pass

    def increase_duration(self):
        self._step_duration(1)

    def decrease_duration(self):
        self._step_duration(-1)

    def _step_duration(self, step):
        try:
            choices = ["5000", "10000", "15000", "20000"]
            current = config.plugins.DiskCpuTemp.warning_duration.value
            try: idx = choices.index(current)
            except: idx = 0
            idx = max(0, min(len(choices)-1, idx + step))
            config.plugins.DiskCpuTemp.warning_duration.value = choices[idx]
            config.plugins.DiskCpuTemp.warning_duration.save()
            
            d_sec = int(choices[idx]) // 1000
            self["settings_label"].setText("Warning Duration: %d seconds" % d_sec)
            self.show_temp_confirmation("Duration: %d seconds" % d_sec)
        except: pass

    def show_temp_confirmation(self, message):
        try:
            orig = self["settings_label"].text
            self["settings_label"].setText(message)
            self.confirm_timer = eTimer()
            try: self.confirm_timer.timeout.connect(lambda: self["settings_label"].setText(orig))
            except: self.confirm_timer.callback.append(lambda: self["settings_label"].setText(orig))
            self.confirm_timer.start(2000, True)
        except: pass

    def show_warning_bar(self, message):
        try: self["warning_bar"].setText(message)
        except: pass

    def clear_warning_bar(self):
        try: self["warning_bar"].setText("")
        except: pass

    def ensure_grgb(self, color):
        if enigma_gRGB and isinstance(color, enigma_gRGB): return color
        if isinstance(color, (tuple, list)) and len(color) >= 3:
            return gRGB(int(color[0]), int(color[1]), int(color[2]))
        return gRGB(255, 255, 255)

    def updateTemps(self):
        try:
            # CPU
            cpu_val = get_cpu_temp()
            self["cpu_label"].setText("CPU Temp: %s" % cpu_val)
            color = self.ensure_grgb(temp_to_color(cpu_val, "CPU"))
            try: self["cpu_label"].instance.setForegroundColor(color)
            except: self["cpu_label"].setForegroundColor(color)
            check_temperature_warnings("CPU", "CPU", cpu_val)

            # Storage
            storage = get_hdd_temps()
            keys = sorted(storage.keys())
            labels = ["hdd1_label", "hdd2_label", "hdd3_label", "hdd4_label"]
            
            for i in range(4):
                if i < len(keys):
                    dev = keys[i]
                    temp = storage[dev]
                    self[labels[i]].setText("%s Temp: %s" % (dev, temp))
                    
                    dtype = "HDD"
                    if "SSD" in dev.upper(): dtype = "SSD"
                    elif "NVME" in dev.upper(): dtype = "NVMe"
                    elif "EMMC" in dev.upper(): dtype = "eMMC"
                    
                    color = self.ensure_grgb(temp_to_color(temp, dtype))
                    try: self[labels[i]].instance.setForegroundColor(color)
                    except: self[labels[i]].setForegroundColor(color)
                    check_temperature_warnings(dtype, dev, temp)
                else:
                    self[labels[i]].setText("")
            
            # Restart timer
            if hasattr(self, 'updateTimer') and self.updateTimer is not None:
                self.updateTimer.start(5000, True)
        except: pass